package com.loyalty.methods;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.interpreter.domain.IShuttingYard;
import com.interpreter.dto.evaluate.InterpreterRequest;
import com.interpreter.dto.evaluate.InterpreterResponse;
import com.interpreter.exception.IntException;
import com.interpreter.implementation.ShuttinYardImpl;

import junit.framework.Assert;

@SpringBootTest
public class ShuttingYardTest {
	
	private InterpreterRequest interpreterRequestMock;
	private InterpreterResponse interpreterResponseMock;
	private InterpreterResponse interpreterResponse;
	private IShuttingYard retrieveShuttingYard = Mockito.mock(ShuttinYardImpl.class);
	private ObjectMapper mapper = new ObjectMapper();
	
	@Before
	public void setUp() throws IntException {
		buildMockREquest();
		buildMockResponse();
		Mockito
		.when(retrieveShuttingYard.evaluateShuttinYard(Mockito.any()))
		.thenReturn(interpreterResponseMock);	
	}
	
	public void buildMockREquest() {
		interpreterRequestMock = new InterpreterRequest();
		interpreterRequestMock.setExp("1 + 2.5 / 3 * 4");
	}
	
	public void buildMockResponse() {
		interpreterResponseMock = new InterpreterResponse();
		interpreterResponseMock.setInfix("1 + 2.5 / 3 * 4");
		interpreterResponseMock.setPostfix("1 2.5 3 / 4 * + ");
		interpreterResponseMock.setResult(0.0);		
	}
	
	@Test
	public void retriveCarDataNullTest() throws IntException {
		interpreterResponse = retrieveShuttingYard.evaluateShuttinYard(interpreterRequestMock);
		Assert.assertFalse(null == interpreterResponse);
	}
	
	@Test
	public void retrieveCardDataResponseTest()throws JsonProcessingException, IntException {
		interpreterResponse = retrieveShuttingYard.evaluateShuttinYard(interpreterRequestMock);
		Assert.assertEquals(mapper.writeValueAsString(interpreterResponse), mapper.writeValueAsString(interpreterResponseMock));
	}
	
	

}
