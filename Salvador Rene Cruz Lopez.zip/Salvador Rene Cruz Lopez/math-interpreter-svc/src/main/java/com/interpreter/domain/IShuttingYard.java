package com.interpreter.domain;

import org.springframework.stereotype.Service;

import com.interpreter.dto.evaluate.InterpreterRequest;
import com.interpreter.dto.evaluate.InterpreterResponse;
import com.interpreter.exception.IntException;
/***
 * 
 * @author srcruzl
 * This interface will provide a method, where you can use to implements a Shutting Yard Method.
 */
public interface IShuttingYard {
	
	/**
	 * 
	 * @param interpreterRequest
	 * @return  a dto to accomplish with contract of InterpreterResponse using  Shutting Yard Method.
	 */
	public InterpreterResponse evaluateShuttinYard(InterpreterRequest interpreterRequest) throws IntException;

}
