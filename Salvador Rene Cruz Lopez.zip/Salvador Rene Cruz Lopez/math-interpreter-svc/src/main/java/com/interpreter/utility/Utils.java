package com.interpreter.utility;

import com.fasterxml.jackson.databind.ObjectMapper;

public class Utils {
	public static String objToString(Object o) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			return mapper.writeValueAsString(o);
		}catch (Exception e){
			return null;
		}
	}
}
