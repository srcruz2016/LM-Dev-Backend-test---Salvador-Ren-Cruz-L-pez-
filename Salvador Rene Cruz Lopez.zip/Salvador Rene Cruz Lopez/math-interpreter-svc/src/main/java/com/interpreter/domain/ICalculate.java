package com.interpreter.domain;
/***
 * 
 * @author srcruzl
 * This interface will provide a boilerplate to implement the different type of calculations.
 */
public interface ICalculate {
	public Double calculate (String expression);

}
