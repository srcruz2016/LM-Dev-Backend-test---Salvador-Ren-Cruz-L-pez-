package com.interpreter.dto.evaluate;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.ALWAYS)
@JsonPropertyOrder({
    "exp"
})
public class InterpreterRequest implements Serializable{

	private static final long serialVersionUID = 1L;

	private String exp;
	
}
