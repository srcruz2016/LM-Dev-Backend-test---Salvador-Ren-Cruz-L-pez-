package com.interpreter.pojo.evaluate;

/***
 * 
 * @author srcruzl This Enum will work to add Operators
 */
public enum Operator {
	ADD(1), SUBTRACT(2), MULTIPLY(3), DIVIDE(4);
	public final int precedence;

	Operator(int p) {
		precedence = p;
	}
}
