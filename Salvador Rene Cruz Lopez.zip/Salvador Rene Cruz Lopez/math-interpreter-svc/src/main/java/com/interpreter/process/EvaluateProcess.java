package com.interpreter.process;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.interpreter.domain.ICalculate;
import com.interpreter.domain.IEvaluateProcess;
import com.interpreter.domain.IShuttingYard;
import com.interpreter.dto.evaluate.InterpreterRequest;
import com.interpreter.dto.evaluate.InterpreterResponse;
import com.interpreter.exception.IntException;

@Service
public class EvaluateProcess implements IEvaluateProcess {

	private Environment env;
	private Logger log;
	private IShuttingYard implShuttingYard;
	// private ICalculate implCalculate;

	@Autowired
	public EvaluateProcess(Environment env, IShuttingYard implShuttingYard) {
		this.env = env;
		this.implShuttingYard = implShuttingYard;
		// this.implCalculate = implCalculate;
	}

	@Override
	public InterpreterResponse evaluateShuttinYardProcess(InterpreterRequest interpreterRequest) throws IntException {

		InterpreterResponse response = new InterpreterResponse();
		response = implShuttingYard.evaluateShuttinYard(interpreterRequest);
		response.setResult(parser(interpreterRequest.getExp()));

		return response;
	}

	private Double parser(String expression) {
		return 0.0;
	}

}
