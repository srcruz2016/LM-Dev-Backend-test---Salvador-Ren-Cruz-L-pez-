package com.interpreter.utility;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.web.client.RestClientException;

public class ServiceRequestGet<T> {

	private RestClient restClient;
	private Logger log;
	
	@Autowired
	public ServiceRequestGet(RestClient restClient) {
		this.restClient = restClient;
		this.log = LoggerFactory.getLogger(getClass());
	}
	
	public T RequestGet(String endpointUrl, ParameterizedTypeReference<T> responseType) {
		T responsePeticion;
		try {
			responsePeticion = restClient.call(
				endpointUrl,
				HttpMethod.GET,
				null,
				responseType);
		}catch(RestClientException | NumberFormatException | InterruptedException | ExecutionException | TimeoutException e){
			log.error(e.getMessage());			
			return null;
		}
				
		return responsePeticion;
	}
	
	public T RequestGetCMS(String endpointUrl, ParameterizedTypeReference<T> responseType) {
		T responsePeticion;
		try {
			responsePeticion = restClient.callCMS(
				endpointUrl,
				HttpMethod.GET,
				null,
				responseType);
		}catch(RestClientException | NumberFormatException | InterruptedException | ExecutionException | TimeoutException e){
			log.error(e.getMessage());			
			return null;
		}
				
		return responsePeticion;
	}
}