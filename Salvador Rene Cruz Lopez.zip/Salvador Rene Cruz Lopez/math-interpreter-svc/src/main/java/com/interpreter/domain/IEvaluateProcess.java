package com.interpreter.domain;

import com.interpreter.dto.evaluate.InterpreterRequest;
import com.interpreter.dto.evaluate.InterpreterResponse;
import com.interpreter.exception.IntException;

public interface IEvaluateProcess {
	/**
	 * 
	 * @param interpreterRequest
	 * @return  a dto to accomplish with contract of InterpreterResponse using  Shutting Yard Method.
	 */
	public InterpreterResponse evaluateShuttinYardProcess(InterpreterRequest interpreterRequest) throws IntException;	


}
