package com.interpreter.utility;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.web.client.AsyncRestTemplate;
import org.springframework.web.client.RestClientException;

public class RestClient {
	AsyncRestTemplate restTemplate;
	private Environment env;
		
	public RestClient(AsyncRestTemplate restTemplate, Environment env){
		this.restTemplate = restTemplate;
		this.env = env;
	}
		
	public <T, U> U call(String url, HttpMethod method, T requestObject, ParameterizedTypeReference<U> responseType,
			Object... uriParams) throws RestClientException, InterruptedException, ExecutionException, NumberFormatException, TimeoutException{
		
		HttpEntity<T> request; 
		MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
		
		headers.add("Authorization", "Basic");
		ResponseEntity<U> response = SetInfoRestCall(url, method, requestObject, responseType, headers, uriParams);

		return response.getBody();
	}
	
	
	public <T, U> U callCMS(String url, HttpMethod method, T requestObject, ParameterizedTypeReference<U> responseType,
			Object... uriParams) throws RestClientException, InterruptedException, ExecutionException, NumberFormatException, TimeoutException{
		
		HttpEntity<T> request; 
		MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
		ResponseEntity<U> response = SetInfoRestCall(url, method, requestObject, responseType, headers, uriParams);

		return response.getBody();
	}
	
	

	private <U, T> ResponseEntity<U> SetInfoRestCall(String url, HttpMethod method, T requestObject,
			ParameterizedTypeReference<U> responseType, MultiValueMap<String, String> headers, Object... uriParams)
			throws InterruptedException, ExecutionException, TimeoutException {
		HttpEntity<T> request;
		headers.add("Content-Type", "application/json");
		headers.add("Accept", "application/json");
		
		
		ListenableFuture<ResponseEntity<U>> listenableFutureResponse = null;
		ResponseEntity<U> response;

		
		request = new HttpEntity<>(requestObject, headers);
		
		listenableFutureResponse = restTemplate.exchange(url, method, request, responseType, uriParams);
		
		response = listenableFutureResponse.get(Long.parseLong(env.getProperty("service.configuration.http.http-request-timeout")), TimeUnit.MILLISECONDS);
		return response;
	}
}