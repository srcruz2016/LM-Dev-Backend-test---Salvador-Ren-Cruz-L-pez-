package com.interpreter.implementation;

import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.regex.Pattern;
import org.springframework.stereotype.Service;
import com.interpreter.domain.IShuttingYard;
import com.interpreter.dto.evaluate.InterpreterRequest;
import com.interpreter.dto.evaluate.InterpreterResponse;
import com.interpreter.exception.IntException;
import com.interpreter.pojo.evaluate.Operator;

@Service 
public class ShuttinYardImpl implements IShuttingYard{
	

	// Regular Expression Pattern to exclude a negative number.
	private static Pattern pattern = Pattern.compile("\\d+(\\.\\d+)?");
	// HashMap to save the diferents operators
	private static Map<String, Operator> ops = new HashMap<String, Operator>() {
		{
			put("+", Operator.ADD); // 1
			put("-", Operator.SUBTRACT); // 2
			put("*", Operator.MULTIPLY); // 3
			put("/", Operator.DIVIDE); // 4
		}
	};
	

	@Override
	public InterpreterResponse evaluateShuttinYard(InterpreterRequest interpreterRequest) throws IntException {
		InterpreterResponse response = new InterpreterResponse(); 
		
			// 1. Retrvie the postFix
			response.setPostfix(getPostfix(interpreterRequest.getExp()));
			// 2. Set the Infix
			response.setInfix(interpreterRequest.getExp());			
										
		return response;
	}
	
	
	/***
	 * @author srcruzl
	 * @param String strNum
	 * @return Boolean True if is a positive number and False if is a Negative Number or if is null
	 * This Method provide a single way to validate a String Number,
	 *
	 */
	public static boolean isNumeric(String strNum) {
		if (strNum == null) {
			return false;
		}
		return pattern.matcher(strNum).matches();
	}
	
	/***
	 * 
	 * @param op as operator
	 * @param sub the last element of the stack
	 * @return a boolean True if is higer o False if is not.
	 */
	private static boolean isHigerPrec(String op, String sub) {
		return (ops.containsKey(sub) && ops.get(sub).precedence >= ops.get(op).precedence);
	}	
	
	/***
	 * 
	 * @param infix String to evaluate
	 * @return a postfix Expresion.
	 */
	public static String getPostfix(String infix) throws IntException {
		StringBuilder output = new StringBuilder();
		Deque<String> stack = new LinkedList<>();

		for (String token : infix.split("\\s")) {		
			if (ops.containsKey(token)) {
				while (!stack.isEmpty() && isHigerPrec(token, stack.peek()))
					output.append(stack.pop()).append(' ');
				stack.push(token);
			} else {

				if (isNumeric(token) == true) {
					output.append(token).append(' ');
				} else {								
					throw new IntException("The expresion " + infix + " is invalid","400");														
				}

			}
		}

		while (!stack.isEmpty())
			output.append(stack.pop()).append(' ');

		return output.toString();
	}

}
