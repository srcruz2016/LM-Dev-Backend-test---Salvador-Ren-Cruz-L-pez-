package com.interpreter.pojo.genericerror;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "code",
    "message"
})
public class GeneralErrorPojo implements Serializable {
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@JsonProperty("code")
	    private String code;
	    @JsonProperty("message")
	    private String message;

}
