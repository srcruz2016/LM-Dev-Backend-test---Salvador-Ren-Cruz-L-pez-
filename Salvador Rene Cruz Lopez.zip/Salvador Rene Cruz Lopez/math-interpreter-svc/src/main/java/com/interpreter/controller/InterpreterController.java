package com.interpreter.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.interpreter.domain.IEvaluateProcess;
import com.interpreter.dto.evaluate.InterpreterRequest;
import com.interpreter.dto.evaluate.InterpreterResponse;
import com.interpreter.exception.IntException;
import com.interpreter.utility.ServiceUtils;


@RestController
@PropertySource("classpath:configuration.properties")
@RequestMapping("${service.url}")
public class InterpreterController {
	private Environment env;
	private Logger log;	
	private IEvaluateProcess evaluateProcess;

	@Autowired
	public InterpreterController(Environment env,IEvaluateProcess evaluateProcess) {
		this.env = env;
		this.log = LoggerFactory.getLogger(getClass());
		this.evaluateProcess = evaluateProcess;
	}
	
	//Endpoint used to evaluate shutting yard
	@PostMapping("${service.url.endpoint.interpreter.evaluate}")
	public InterpreterResponse evaluateMethod(@RequestBody InterpreterRequest interpreterRequest) throws IntException {
		log.info("InterpreterRequest: "+ ServiceUtils.objToString(interpreterRequest) );
		InterpreterResponse response = new InterpreterResponse();
		response = evaluateProcess.evaluateShuttinYardProcess(interpreterRequest);
		log.info("InterpreterResponse: " + ServiceUtils.objToString(response));
		return response;
	}
	


}
